const form = document.getElementById('form')

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const city = document.getElementById('city').value
  const pop = document.getElementById('pop').value
  const cityid = document.getElementById('put_ID').value
  const PUTcity = document.getElementById('put_city').value
  const PUTpop = document.getElementById('put_pop').value

  //POST request
  fetch('https://avancera.app/cities/', {
    method: 'POST',
    body: JSON.stringify({
      name: city,
      population: parseInt(pop),

    }),
    headers: {
      'Content-type': 'application/json'
    }
  })
    .then(function (response) {
      return response.json()
    })
    .then(function (data) {
      console.log(data)
    }).catch(error => console.error('Error:', error));



  // PUT request

  const formPUT = document.getElementById('formPUT')

  formPUT.addEventListener('submit', function (e) {
    e.preventDefault();


    //PUT request
    fetch('https://avancera.app/cities/' + cityid, {
      method: 'PUT',
      body: JSON.stringify({
        "id": (cityid),
        "name": (PUTcity),
        "population": parseInt(PUTpop),

      }),
      headers: {
        'Content-type': 'application/json'
      }
    })
      .then(function (response) {
        return response.json()
      })
      .then(function (data) {
        console.log(data)
      }).catch(error => console.error('Error:', error));

  });
});


//GET request
fetch('https://avancera.app/cities/')
  .then(response => response.json())
  .then(data => {
    console.log(data)
    let content = '';

    //Taking the data and mapping the information
    data.map(p => {


      //Proceeding to "paint my HTML Dom"
      content += `

      <div class="card" style="width: 25rem;">
        <div class="card-body">
          <h1 class="card-title" id="itemName">City: ${p.name}<h1>
          <p class="card-text" id="itemDesc">Population: ${p.population}</p>
        </div>
      </div>

    `

    });

    document.querySelector("#cities").innerHTML = content;

  }).catch(error => {
    console.log(error)
  })
